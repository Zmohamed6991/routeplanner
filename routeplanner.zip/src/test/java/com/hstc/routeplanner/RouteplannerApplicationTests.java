package com.hstc.routeplanner;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RouteplannerApplicationTests {

	@Test
	void contextLoads() {
	}

}
