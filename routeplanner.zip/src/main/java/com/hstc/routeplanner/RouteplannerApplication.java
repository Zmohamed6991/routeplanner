package com.hstc.routeplanner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RouteplannerApplication {

	public static void main(String[] args) {
		SpringApplication.run(RouteplannerApplication.class, args);
	}

}
