package com.hstc.routeplanner.model;

public class Connection {
    private String id;
    private int hu;

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public int getHu() { return hu; }
    public void setHu(int hu) { this.hu = hu; }
}